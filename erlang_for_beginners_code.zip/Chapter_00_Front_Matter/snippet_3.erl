Module names match file names: my_mod.erl contains -module(my_mod).
