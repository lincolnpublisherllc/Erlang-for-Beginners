%% File: classify.erl
-module(classify).
-export([sign/1]).
