%% File: headtail.erl
-module(headtail).
-export([describe/1]).
