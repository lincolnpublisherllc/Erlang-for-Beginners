%% File: normalize_user.erl
-module(normalize_user).
-export([normalize/1]).
