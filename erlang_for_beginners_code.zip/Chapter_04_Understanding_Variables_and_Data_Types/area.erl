%% File: area.erl
-module(area).
-export([of/1]).
