%% File: users.erl
-module(users).
-export([name_of/1]).
