%% File: folds.erl
-module(folds).
-export([sum/1, count_true/1, to_map/1]).
