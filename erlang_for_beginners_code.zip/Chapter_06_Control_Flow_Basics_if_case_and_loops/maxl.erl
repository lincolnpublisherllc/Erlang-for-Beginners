%% File: maxl.erl
-module(maxl).
-export([max/1]).
