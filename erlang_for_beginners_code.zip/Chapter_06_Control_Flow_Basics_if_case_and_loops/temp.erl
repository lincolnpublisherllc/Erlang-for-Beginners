%% File: temp.erl
-module(temp).
-export([feel/1]).
