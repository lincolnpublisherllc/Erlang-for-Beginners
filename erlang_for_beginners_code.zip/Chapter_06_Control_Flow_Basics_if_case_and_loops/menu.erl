%% File: menu.erl
-module(menu).
-export([run/0]).
