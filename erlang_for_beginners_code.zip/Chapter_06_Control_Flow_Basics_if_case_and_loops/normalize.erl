%% File: normalize.erl
-module(normalize).
-export([sum_and_count/1]).
