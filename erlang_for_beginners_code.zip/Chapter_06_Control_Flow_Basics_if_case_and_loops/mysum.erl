%% File: mysum.erl
-module(mysum).
-export([sum/1]).
