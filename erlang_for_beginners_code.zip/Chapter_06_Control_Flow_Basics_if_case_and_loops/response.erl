%% File: response.erl
-module(response).
-export([status/1]).
