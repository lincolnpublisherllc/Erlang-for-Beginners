%% File: auth.erl
-module(auth).
-export([role/1]).
