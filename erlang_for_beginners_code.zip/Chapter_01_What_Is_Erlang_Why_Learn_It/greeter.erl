%% File: greeter.erl
%% A tiny module with one exported function.
