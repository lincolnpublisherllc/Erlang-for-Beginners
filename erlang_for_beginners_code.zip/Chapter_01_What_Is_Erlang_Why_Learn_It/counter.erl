%% File: counter.erl
-module(counter).
-export([run/0]).
