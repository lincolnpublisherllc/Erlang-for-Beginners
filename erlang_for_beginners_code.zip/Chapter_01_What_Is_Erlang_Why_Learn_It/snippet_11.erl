-module(greeter). sets the module name that must match the filename without .erl.
-export([hello/1]). makes the function available to callers. The /1 means arity 1, or one argument.
io:format/2 prints with a placeholder ~s for a string-like list.
