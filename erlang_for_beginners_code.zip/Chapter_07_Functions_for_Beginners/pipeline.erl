%% File: pipeline.erl
-module(pipeline).
-export([run/2, trim/1, to_int/1]).
