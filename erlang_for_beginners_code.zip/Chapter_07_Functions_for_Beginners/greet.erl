%% File: greet.erl
-module(greet).
-export([hello/1]).
