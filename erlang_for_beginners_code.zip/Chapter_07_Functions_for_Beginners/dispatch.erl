%% File: dispatch.erl
-module(dispatch).
-export([run/2, default_ops/0]).
