%% File: absval.erl
-module(absval).
-export([abs/1]).
