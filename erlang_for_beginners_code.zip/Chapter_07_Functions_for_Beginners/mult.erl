%% File: mult.erl
-module(mult).
-export([by/1]).
