%% File: funref.erl
-module(funref).
-export([square/1, apply_all/2]).
