%% File: safe_div.erl
-module(safe_div).
-export([div/2]).
