%% File: mathx.erl
-module(mathx).
-export([mul/2, pow2/1]).
