%% File: stats.erl
-module(stats).
-export([mean/1, median/1]).
