pow2(N) ->
    N * N.
-module(mathx). ties the code to mathx.erl.
-export([...]). lists functions that other modules can call. Keep this list small. Export the public API. Leave helpers unexported.
