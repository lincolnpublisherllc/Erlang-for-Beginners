%% File: hello_opt.erl
-module(hello_opt).
-export([hello/0, hello/1]).
