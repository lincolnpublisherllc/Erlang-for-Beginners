%% File: basics.erl
-module(basics).
-export([sum/2, sum/3]).
