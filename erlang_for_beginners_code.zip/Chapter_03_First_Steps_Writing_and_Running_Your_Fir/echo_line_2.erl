erlc -o ebin src/echo_line.erl
erl -pa ebin
1> echo_line:run().
