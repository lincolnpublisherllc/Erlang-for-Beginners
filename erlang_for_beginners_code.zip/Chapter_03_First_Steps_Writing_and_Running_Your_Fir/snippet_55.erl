Wrong module name
File is hello.erl but inside you wrote -module(goodbye). They must match.
