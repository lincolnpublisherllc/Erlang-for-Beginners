erlc hello.erl
erlc greeter.erl
erl
1> hello:world().
