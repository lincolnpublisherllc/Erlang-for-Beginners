erlc -o ebin src/add2.erl
erl -pa ebin
1> add2:run().
