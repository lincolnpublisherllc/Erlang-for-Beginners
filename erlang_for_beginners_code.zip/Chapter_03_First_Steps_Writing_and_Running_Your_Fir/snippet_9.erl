-module(hello). ties the code to the file name hello.erl.
-export([world/0]). makes the function callable from other modules and from the shell. /0 means the function takes zero arguments.
world() calls io:format/2 to print a line.
