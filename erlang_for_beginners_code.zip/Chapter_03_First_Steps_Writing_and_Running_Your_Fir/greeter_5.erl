erlc -o ebin src/hello.erl
erlc -o ebin src/greeter.erl
