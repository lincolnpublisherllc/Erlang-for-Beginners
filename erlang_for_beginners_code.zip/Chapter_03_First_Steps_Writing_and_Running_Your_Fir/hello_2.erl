erlc hello.erl
