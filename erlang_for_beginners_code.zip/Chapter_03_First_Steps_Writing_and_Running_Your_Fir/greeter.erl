%% File: greeter.erl
-module(greeter).
-export([hello/1]).
