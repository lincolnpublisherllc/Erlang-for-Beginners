%% File: src/add2.erl
-module(add2).
-export([run/0]).
