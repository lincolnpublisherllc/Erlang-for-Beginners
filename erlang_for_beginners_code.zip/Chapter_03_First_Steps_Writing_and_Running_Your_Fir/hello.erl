%% File: hello.erl
%% A tiny module with one exported function.
