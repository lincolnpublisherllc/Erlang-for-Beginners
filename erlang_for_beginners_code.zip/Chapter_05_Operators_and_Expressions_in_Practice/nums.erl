%% File: nums.erl
-module(nums).
-export([evens/1, squares/1, pairs/1]).
