%% File: rgb.erl
-module(rgb).
-export([red/1, green/1, blue/1]).
