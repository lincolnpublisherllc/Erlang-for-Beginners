%% File: evenodd.erl
-module(evenodd).
-export([classify/1]).
