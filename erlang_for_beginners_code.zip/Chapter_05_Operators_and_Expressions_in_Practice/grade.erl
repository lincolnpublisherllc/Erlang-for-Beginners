%% File: grade.erl
-module(grade).
-export([letter/1]).
