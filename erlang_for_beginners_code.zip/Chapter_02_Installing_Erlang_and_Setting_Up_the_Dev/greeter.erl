%% File: src/greeter.erl
-module(greeter).
-export([hello/1]).
